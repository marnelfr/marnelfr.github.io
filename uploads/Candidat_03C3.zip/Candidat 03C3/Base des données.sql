-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.0.38-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table gestion_personnel.sys_departement
CREATE TABLE IF NOT EXISTS `sys_departement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table gestion_personnel.sys_departement: 4 rows
/*!40000 ALTER TABLE `sys_departement` DISABLE KEYS */;
INSERT INTO `sys_departement` (`id`, `libelle`) VALUES
	(1, 'Informatique'),
	(2, 'Pole negoce'),
	(3, 'Audit'),
	(4, 'Contrôles qualité');
/*!40000 ALTER TABLE `sys_departement` ENABLE KEYS */;

-- Dumping structure for table gestion_personnel.sys_employe
CREATE TABLE IF NOT EXISTS `sys_employe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_employe` varchar(255) NOT NULL,
  `prenom_employe` varchar(255) NOT NULL,
  `id_departement` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_2AED620D38B217A7` (`id_departement`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table gestion_personnel.sys_employe: 0 rows
/*!40000 ALTER TABLE `sys_employe` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_employe` ENABLE KEYS */;

-- Dumping structure for table gestion_personnel.sys_users
CREATE TABLE IF NOT EXISTS `sys_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table gestion_personnel.sys_users: 0 rows
/*!40000 ALTER TABLE `sys_users` DISABLE KEYS */;
INSERT INTO `sys_users` (`id`, `nom`, `prenom`, `email`, `password`) VALUES
	(1, 'GNACADJA', 'Marnel', 'nel@dev.fr', '0181ba2be11b9b8ead20b0cd6397c138');
/*!40000 ALTER TABLE `sys_users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
