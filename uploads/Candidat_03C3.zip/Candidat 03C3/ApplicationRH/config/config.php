<?php 

return [
    "db_name" => "gestion_personnel",
    "db_user" => "root",
    "db_pass" => "",
    "db_host" => "localhost",
];
