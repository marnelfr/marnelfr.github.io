<?php
namespace App\Model;

use Core\Model\Model;

class CreditModel extends Model{

    protected $table = 'sys_users';

}