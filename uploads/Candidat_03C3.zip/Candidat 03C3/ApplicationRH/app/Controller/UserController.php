<?php
namespace App\Controller;


class UserController extends AppController{

    protected $template = 'backend';
    protected $idConnected;
    protected $user;
    protected $col;

    public function __construct() {
        parent::__construct();
        $this->loadModel('User');
    }

    public function index(){
        $user = session('logged');
        $fullname = $user->nom . ' ' . $user->prenom;
        return $this->view('users.accueil', compact('fullname'));
    }



    public function logout(){
        session_destroy();
        header('location:?p=welcome/index');
    }

}