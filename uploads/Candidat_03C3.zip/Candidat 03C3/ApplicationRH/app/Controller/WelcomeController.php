<?php
namespace App\Controller;

class WelcomeController extends AppController{

    protected $template = 'connexion';


    public function index(){
        return $this->view('connexion');
    }
    
    public function notfound(){
        die('Not found');
    }



}