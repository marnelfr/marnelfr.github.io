<?php
namespace App\Controller;

use App\Model\UserModel;
class GuestController extends AppController{


    public function __construct(){
        parent::__construct();
        $this->loadModel('User');
        $this->loadModel('Credit');
        $this->loadModel('Lock');
    }

    public function authentication($email = null, $pwd = null){
        if(($email === null) and ($pwd === null)){
            if(isset($_POST['mdp']) and isset($_POST['email'])){
                $user = $this->User->finder(strip_tags($_POST['email']));
                if($user){
                    if($user->password == md5(sha1(strip_tags($_POST['mdp'])))){
                        session('logged', $user);
                        header('location:?p=user/index');
                    }else{
                        session('badPwd', true);
                        header('location:index.php?p=welcome/index');
                    }
                }else{
                    session('notFound', true);
                    header('location:index.php?p=welcome/index');
                }
            }else{
                session('void', true);
                header('location:index.php?p=welcome/index');
            }
        }else{
            $user = $this->User->finder(strip_tags($email));
            if($user){
                if($user->password === md5(sha1(strip_tags($pwd)))){
                    session('logged', $user->idUser);
                    header('location:?p=user/index');
                }else{
                    session('badPwd', true);
                    header('location:index.php?p=welcome/index');
                }
            }else{
                session('notFound', true);
                header('location:index.php?p=welcome/index');
            }
        }
    }

}